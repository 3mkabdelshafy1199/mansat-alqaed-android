# منصة القائد — مشروع Android APK

هذا مشروع Android بسيط يستخدم WebView لعرض موقع تعليمي محليًا من ملفات assets.

## البناء
- يتطلب JDK 17 وAndroid SDK API 35.
- من داخل مجلد `android-project` شغّل: `gradle assembleDebug`
- ملف APK الناتج: `app/build/outputs/apk/debug/app-debug.apk`

## محتوى المشروع
- `app/src/main/AndroidManifest.xml`
- `app/src/main/java/com/mansatalqaed/app/MainActivity.java`
- `app/src/main/assets/` يحتوي واجهة HTML وCSS وJavaScript.

المحتوى التاريخي داخل التطبيق تجريبي ويحتاج مراجعة واستكمال المنهج قبل الاستخدام التعليمي الرسمي.
